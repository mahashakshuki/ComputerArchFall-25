from Tomasolo_final.engine import run_simulation
from Tomasolo_final import state
from Tomasolo_final.instruction import Instruction


def parse_program(lines):
    program = []
    pc = 0
    for line in lines:
        line = line.strip()
        if not line:
            continue
        program.append(Instruction.from_asm(line, pc))
        pc += 1
    return program


def simulate(program_text: str):
    import importlib
    importlib.reload(state)

    lines = program_text.splitlines()
    program = parse_program(lines)

    state.instruction_queue = program

    run_simulation()

    return {
        "cycles": state.cycle,
        "ipc": len(program) / max(1, state.cycle),
        "misp": state.mispredict_count,
        "timeline": state.timeline,
        "regs": state.registers.copy(),
        "rob": [e.to_dict() for e in state.ROB],
        "rs": [e.to_dict() for e in state.all_reservation_stations()],
    }
