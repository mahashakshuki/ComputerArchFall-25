async function runSimulation() {
    const program = document.getElementById("programInput").value;

    const simulateFn = pyscript.runtime.globals.get("simulate");
    const result = await simulateFn(program);

    renderOutput(result);
    renderROB(result.rob);
    renderRS(result.rs);
    renderRegfile(result.regs);
}

function renderOutput(result) {
    let html = `
        <h3>Performance</h3>
        <p><b>Cycles:</b> ${result.cycles}</p>
        <p><b>IPC:</b> ${result.ipc}</p>
        <p><b>Mispredictions:</b> ${result.misp}</p>

        <h3>Instruction Timeline</h3>
        <table>
            <tr>
                <th>Instr</th><th>Issue</th><th>Exec Start</th>
                <th>Exec End</th><th>Write</th><th>Commit</th>
            </tr>
    `;

    for (const row of result.timeline) {
        html += `
            <tr>
                <td>${row.text}</td>
                <td>${row.issue}</td>
                <td>${row.exec_start}</td>
                <td>${row.exec_end}</td>
                <td>${row.write}</td>
                <td>${row.commit}</td>
            </tr>`;
    }

    html += "</table>";
    document.getElementById("output").innerHTML = html;
}

function renderROB(rob) {
    let html = "<table><tr><th>Idx</th><th>Busy</th><th>Dest</th><th>Value</th><th>Ready</th></tr>";
    rob.forEach((e, i) => {
        html += `<tr>
            <td>${i}</td>
            <td>${e.busy}</td>
            <td>${e.dest}</td>
            <td>${e.value}</td>
            <td>${e.ready}</td>
        </tr>`;
    });
    html += "</table>";
    document.getElementById("rob").innerHTML = html;
}

function renderRS(rs) {
    let html = "<table><tr><th>Name</th><th>Busy</th><th>Op</th><th>Vj</th><th>Vk</th><th>Qj</th><th>Qk</th></tr>";
    rs.forEach(r => {
        html += `<tr>
            <td>${r.name}</td>
            <td>${r.busy}</td>
            <td>${r.op}</td>
            <td>${r.Vj}</td>
            <td>${r.Vk}</td>
            <td>${r.Qj}</td>
            <td>${r.Qk}</td>
        </tr>`;
    });
    html += "</table>";
    document.getElementById("rs").innerHTML = html;
}

function renderRegfile(regs) {
    let html = "<table><tr><th>Reg</th><th>Val</th></tr>";
    for (let i = 0; i < regs.length; i++) {
        html += `<tr><td>R${i}</td><td>${regs[i]}</td></tr>`;
    }
    html += "</table>";
    document.getElementById("regfile").innerHTML = html;
}
